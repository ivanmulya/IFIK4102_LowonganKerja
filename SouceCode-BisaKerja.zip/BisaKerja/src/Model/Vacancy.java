/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author Mulyadi
 */
public class Vacancy {
    private String vacancyId;
    private String vacancyTitle;
    private String salary;
    private String vacancyType;
    private String vacancyDesc;
    private String status;
    private ArrayList<JobSeeker> jobSeekerList;

    public Vacancy(String vacancyId, String vacancyTitle, String salary, String vacancyType, String vacancyDesc, String status) {
        this.vacancyId = vacancyId;
        this.vacancyTitle = vacancyTitle;
        this.salary = salary;
        this.vacancyType = vacancyType;
        this.vacancyDesc = vacancyDesc;
        this.status = status;
        this.jobSeekerList = new ArrayList();
    }

    public String getVacancyId() {
        return vacancyId;
    }

    public String getVacancyTitle() {
        return vacancyTitle;
    }

    public String getSalary() {
        return salary;
    }

    public String getVacancyType() {
        return vacancyType;
    }

    public String getVacancyDesc() {
        return vacancyDesc;
    }

    public String getStatus() {
        return status;
    }

    public ArrayList<JobSeeker> getJobSeekerList() {
        return jobSeekerList;
    }

    public void setJobSeekerList(ArrayList<JobSeeker> jobSeekerList) {
        this.jobSeekerList = jobSeekerList;
    }

    @Override
    public String toString() {
        return  "vacancy Title\t: " + vacancyTitle + "\nsalary\t: " + salary + "\nvacancy Type\t: " + vacancyType + "\n\nvacancy Description :\n" + vacancyDesc ;
    }
    
}

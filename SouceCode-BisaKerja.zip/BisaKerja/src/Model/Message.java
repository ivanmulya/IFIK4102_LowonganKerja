/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Mulyadi
 */
public class Message {
    private String mid;
    private String messageReview;
    private String messageDetails;

    public Message(String mid, String messageReview, String messageDetails) {
        this.mid = mid;
        this.messageReview = messageReview;
        this.messageDetails = messageDetails;
    }

    public void setRoleid(String roleid) {
        this.mid = roleid;
    }

    public void setMessageReview(String messageReview) {
        this.messageReview = messageReview;
    }

    public void setMessageDetails(String messageDetails) {
        this.messageDetails = messageDetails;
    }

    public String getMid() {
        return mid;
    }

    public String getMessageReview() {
        return messageReview;
    }

    public String getMessageDetails() {
        return messageDetails;
    }
    
    
}

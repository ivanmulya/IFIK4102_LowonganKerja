/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database.Database;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Mulyadi
 */
public class Model {
    Database db;
    User user;
    ArrayList<Vacancy> vacancylist = new ArrayList();
    ArrayList<Message> messagelist = new ArrayList();
    ArrayList<JobSeeker> applicant = new ArrayList();
    JobSeeker specificApplicant;
    JobProvider specificJobProvider;
    Vacancy specificVacancy;

    public Vacancy getSpecificVacancy() {
        return specificVacancy;
    }

    public JobProvider getSpecificJobProvider() {
        return specificJobProvider;
    }

    public void setSpecificVacancy(int index) {
        String vid = vacancylist.get(index).getVacancyId();
        this.specificVacancy=db.loadVacancy(vid);
    }
    
    
    
    public void setSpecificJobProvider(int index) {
        String vid = vacancylist.get(index).getVacancyId();
        this.specificJobProvider= db.loadJpUser2(vid);
    }

    
    public void setSpecificApplicant(int index) {
        this.specificApplicant= applicant.get(index);
    }

    public JobSeeker getSpecificApplicant() {
        return specificApplicant;
    }
    
    
    public String[] getApplicantList(int index) {
        applicant = db.loadApplicant1(vacancylist.get(index).getVacancyId());
        String[] temp= new String[applicant.size()];
        for (int i = 0; i < applicant.size(); i++) {
            temp[i]=applicant.get(i).getName();
        }
        return temp;
    }

    
     
    public Model() {
        db = new Database();
        db.connect();
    }

    public String[] getVacancylist() {
        String[] temp= new String[vacancylist.size()];
        for (int i = 0; i < vacancylist.size(); i++) {
            setSpecificJobProvider(i);
            temp[i]=vacancylist.get(i).getVacancyTitle()+" - "+specificJobProvider.getCompanyName();
        }
        return temp;
    }
    
    public String[] getMessagelist1() {
        String[] temp= new String[messagelist.size()];
        for (int i = 0; i < messagelist.size(); i++) {
            temp[i]=messagelist.get(i).getMessageReview();
        }
        return temp;
    }
    
    public String[] getMessagelist2() {
        String[] temp= new String[messagelist.size()];
        for (int i = 0; i < messagelist.size(); i++) {
            temp[i]=messagelist.get(i).getMessageDetails();
        }
        return temp;
    }
    
    public String[] getMessagelist3() {
        String[] temp= new String[messagelist.size()];
        for (int i = 0; i < messagelist.size(); i++) {
            temp[i]=messagelist.get(i).getMid();
        }
        return temp;
    }
    
    public void deleteMessage(String data){
        db.deleteMessage(data);
    }

    public User getUser() {
        return user;
    }
    
    public void loadVacancyList1(String jpid){
        this.vacancylist= db.loadVacancyFromSpecificUser1(jpid);
    }
    public void loadVacancyList2(){
        this.vacancylist= db.loadAllVacancy();
    }
    
    public void loadMessageList(String roleid){
        this.messagelist=db.loadMessageFromSpecificUser(roleid);
    }
    
    
    public String setRoleId(int i){
        if(i==1){
            return generateIdJs();
        }else if (i==2){
            return generateIdJp();
        }else{
            return "";
        }
    }
    
    public String generateIdJs(){
        ArrayList<String> listUser = new ArrayList();
        listUser= db.loadJobSeekerId();
        
        if(listUser.isEmpty()){
            return "js1";
        }
        else{
            int n = listUser.size();
            int[] arr = new int[n+1];
            for (int i = 0; i < n; i++) {
                arr[i]= Integer.parseInt ( listUser.get(i).replace("js", ""));
            }
            arr[n]=999999999;
            Arrays.sort(arr);

            
            int a = 1;
            int i = 0;
            while(arr[i]==a && a<=n){
                if(a==arr[i]){
                    a += 1;
                    i += 1;
                }
            }
            return "js"+String.valueOf(a); 
        }
    }
    
    public String generateIdJp(){
        ArrayList<String> listUser = new ArrayList();
        listUser= db.loadJobProviderId();
        
        if(listUser.isEmpty()){
            return "jp1";
        }
        else{
            int n = listUser.size();
            int[] arr = new int[n+1];
            for (int i = 0; i < n; i++) {
                arr[i]= Integer.parseInt ( listUser.get(i).replace("jp", ""));
            }
            arr[n]=999999999;
            Arrays.sort(arr);

            
            int a = 1;
            int i = 0;
            while(arr[i]==a && a<=n){
                if(a==arr[i]){
                    a += 1;
                    i += 1;
                }
            }
            return "jp"+String.valueOf(a); 
        }
    }
    
    public boolean checkUsername(String un){
        ArrayList<String> listUser = new ArrayList();
        listUser = db.loadUsername();
        for (int i = 0; i < listUser.size(); i++) {
            if(listUser.get(i).equals(un)){
                return false;
            }
        }
        return true;
    }
    
     public boolean checkPassword(String pass){
        ArrayList<String> listUser = new ArrayList();
        listUser = db.loadPassword();
        for (int i = 0; i < listUser.size(); i++) {
            if(listUser.get(i).equals(pass)){
                return false;
            }
        }
        return true;
    }
    
    public void registerUser(String username, String password, String roleId){
        if(roleId.charAt(1)=='s'){
            this.user = new JobSeeker(username, password,roleId);
        }else{
            this.user = new JobProvider(username, password,roleId);
        }
        
        db.saveUser(user);
    }
    
    public void loadUser(String un){
        user=db.loadSpecificUser(un);
    }
    
    public void updateProfileJSProfile(String jsid, String fullname, String email, String contactnum, String age, String gender, String experience){
        db.SaveJSProfile(jsid, fullname, email, contactnum, age, gender, experience);
        ((JobSeeker) user).setName(fullname);
        ((JobSeeker) user).setEmail(email);
        ((JobSeeker) user).setContactNum(contactnum);
        ((JobSeeker) user).setAge(age);
        ((JobSeeker) user).setGender(gender);
        ((JobSeeker) user).setExperience(experience);
    }
    
    public void updateProfileJPProfile(String jpid, String companyname, String companysize, String socialmedia, String linkedn, String companydesc){
        db.SaveJPProfile(jpid, companyname, companysize, socialmedia, linkedn, companydesc);
        ((JobProvider) user).setCompanyName(companyname);
        ((JobProvider) user).setCompanySize(companysize);
        ((JobProvider) user).setSocialmedia(socialmedia);
        ((JobProvider) user).setLinkdn(linkedn);
        ((JobProvider) user).setCompanydesc(companydesc);
        
    }
    
    public void registerVacancy(String vid, String jpid, String title, String salary, String type, String desc, String status){
        db.saveVacancy(vid, jpid, title, salary, type, desc, status);
    }
    
    public String generateVid(){
        ArrayList<String> listUser = new ArrayList();
        listUser= db.loadVacancyId();
        
        if(listUser.isEmpty()){
            return "vid1";
        }
        else{
            int n = listUser.size();
            int[] arr = new int[n+1];
            for (int i = 0; i < n; i++) {
                arr[i]= Integer.parseInt ( listUser.get(i).replace("vid", ""));
            }
            arr[n]=999999999;
            Arrays.sort(arr);

            
            int a = 1;
            int i = 0;
            while(arr[i]==a && a<=n){
                if(a==arr[i]){
                    a += 1;
                    i += 1;
                }
            }
            return "vid"+String.valueOf(a); 
        }
    }
    
    public void registerMessage(String mid, String roleid, String messagepreview, String messagedetails){
        db.saveMessage(mid, roleid, messagepreview, messagedetails);
    }
    
    public String generateMid(){
        ArrayList<String> listUser = new ArrayList();
        listUser= db.loadMessageId();
        
        if(listUser.isEmpty()){
            return "mid1";
        }
        else{
            int n = listUser.size();
            int[] arr = new int[n+1];
            for (int i = 0; i < n; i++) {
                arr[i]= Integer.parseInt ( listUser.get(i).replace("mid", ""));
            }
            arr[n]=999999999;
            Arrays.sort(arr);

            
            int a = 1;
            int i = 0;
            while(arr[i]==a && a<=n){
                if(a==arr[i]){
                    a += 1;
                    i += 1;
                }
            }
            return "mid"+String.valueOf(a); 
        }
    }
    
    
    public void registerApplicant(String aid,String vid, String jsid){
        db.saveApplicant(aid, vid, jsid);
    }
    
    public String generateAid(){
        ArrayList<String> listUser = new ArrayList();
        listUser= db.loadApplicantId();
        
        if(listUser.isEmpty()){
            return "aid1";
        }
        else{
            int n = listUser.size();
            int[] arr = new int[n+1];
            for (int i = 0; i < n; i++) {
                arr[i]= Integer.parseInt ( listUser.get(i).replace("aid", ""));
            }
            arr[n]=999999999;
            Arrays.sort(arr);

            
            int a = 1;
            int i = 0;
            while(arr[i]==a && a<=n){
                if(a==arr[i]){
                    a += 1;
                    i += 1;
                }
            }
            return "aid"+String.valueOf(a); 
        }
    }
    
    public boolean checkApplyApplicant(String vid, String jsid){
        return db.checkApply(vid, jsid);
    }
    
    public String getMessageSented(String vid, String jsid){
        return db.loadMessageSented(vid, jsid);
    }
    
    public void setMessageSentedPlus1(String vid, String jsid, String data){
        db.saveMessageSented(vid, jsid, data);
    }
}

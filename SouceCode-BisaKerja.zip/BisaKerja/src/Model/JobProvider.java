/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author Mulyadi
 */
public class JobProvider extends User{
    private String jpId="";
    private String companyName="";
    private String companySize="";
    private String socialmedia="";
    private String linkdn="";
    private String companydesc="";
    private ArrayList<Vacancy> vacancyList;
    private ArrayList<Message> messageList;

    public JobProvider(String username, String password, String jpId) {
        super(username, password);
        this.jpId=jpId;
        vacancyList= new ArrayList();
        messageList = new ArrayList();
    }

    public JobProvider(String username, String password, String jpId, String companyName, String companySize, String socialmedia, String linkdn, String companydesc) {
        super(username, password);
        this.jpId = jpId;
        this.companyName = companyName;
        this.companySize = companySize;
        this.socialmedia = socialmedia;
        this.linkdn = linkdn;
        this.companydesc = companydesc;
        vacancyList= new ArrayList();
        messageList = new ArrayList();
    }    

    public void setJpId(String jpId) {
        this.jpId = jpId;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setCompanySize(String companySize) {
        this.companySize = companySize;
    }

    public void setSocialmedia(String socialmedia) {
        this.socialmedia = socialmedia;
    }

    public void setLinkdn(String linkdn) {
        this.linkdn = linkdn;
    }

    public void setCompanydesc(String companydesc) {
        this.companydesc = companydesc;
    }

    public void setVacancyList(ArrayList<Vacancy> vacancyList) {
        this.vacancyList = vacancyList;
    }

    public void setMessageList(ArrayList<Message> messageList) {
        this.messageList = messageList;
    }
    
    
    public String getJpId() {
        return jpId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getCompanySize() {
        return companySize;
    }

    public String getSocialmedia() {
        return socialmedia;
    }

    public String getLinkdn() {
        return linkdn;
    }

    public String getCompanydesc() {
        return companydesc;
    }

    public ArrayList<Vacancy> getVacancyList() {
        return vacancyList;
    }

    public ArrayList<Message> getMessageList() {
        return messageList;
    }
    
    public String toString(){
        return jpId + "\n" +companyName+ "\n" +companySize+ "\n" +socialmedia+ "\n" +linkdn+ "\n" +companydesc  ;
    }
}

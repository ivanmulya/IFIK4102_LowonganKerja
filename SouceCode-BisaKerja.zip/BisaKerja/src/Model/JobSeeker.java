/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author Mulyadi
 */
public class JobSeeker extends User {
    private String jsId="";
    private String name="";
    private String email="";
    private String contactNum="";
    private String age="";
    private String gender="";
    private String experience="";
    private ArrayList<Message> messageList;

    public JobSeeker(String username, String password, String jsId) {
        super(username, password);
        this.jsId=jsId;
        messageList= new ArrayList();
    }
    
    public JobSeeker(String username, String password, String jsId, String name,  String email, String contactNum, String age,  String gender, String experience) {
        super(username, password);
        this.jsId = jsId;
        this.name = name;
        this.email = email;        
        this.contactNum = contactNum;
        this.age = age;
        this.gender = gender;
        this.experience = experience;
        messageList = new ArrayList();
    }

    public void setJsId(String jsId) {
        this.jsId = jsId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setContactNum(String contactNum) {
        this.contactNum = contactNum;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public void setMessageList(ArrayList<Message> messageList) {
        this.messageList = messageList;
    }

    public String getJsId() {
        return jsId;
    }

    public String getName() {
        return name;
    }

    public String getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getContactNum() {
        return contactNum;
    }

    public String getGender() {
        return gender;
    }

    public String getExperience() {
        return experience;
    }    

    public ArrayList<Message> getMessageList() {
        return messageList;
    }
    
    @Override
    public String toString(){
        return jsId + "\n" +name+ "\n" +email+ "\n" +contactNum+ "\n" +age+ "\n" +gender+ "\n" +experience  ;
    }
    
}

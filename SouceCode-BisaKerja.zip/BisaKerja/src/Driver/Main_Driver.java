/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this GUI_Template file, choose Tools | Templates
 * and open the GUI_Template in the editor.
 */
package Driver;

import Controller.Cont_SignIn;
import Model.Model;

/**
 *
 * @author Mulyadi
 */
public class Main_Driver  {
    public static void main(String[] args) {
        Model model = new Model();
        Cont_SignIn cont_SignIn = new Cont_SignIn(model);            
    }
}

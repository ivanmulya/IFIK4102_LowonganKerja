/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package Database;

import Model.JobProvider;
import Model.JobSeeker;
import Model.Message;
import Model.User;
import Model.Vacancy;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Mulyadi
 */
public class Database {
    public Connection con;
    
    public void connect(){
        try {
            String url="jdbc:mysql://192.168.1.21/db_bisakerja";
            String username="ivanmulya";
            String pass="sdasdadas1";
            
            con = DriverManager.getConnection(url, username, pass);
            System.out.println("connected");
        }
        catch(SQLException ex){
            System.out.println("Connection Error");
            ex.printStackTrace();
        }
    }
    
    
    
    
    
    public ArrayList<String> loadJobSeekerId(){
        try{
            ArrayList<String> userIdList = new ArrayList();
            Statement stmt=con.createStatement();
            String query = "select * from jobseeker";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                String id=rs.getString(1);
                userIdList.add(id);
            }
            return userIdList;
        }
        catch(Exception e){
            System.out.println("Error loading jsId");
            return null;
        }
    }
    
    public ArrayList<String> loadJobProviderId(){
        try{
            ArrayList<String> userIdList = new ArrayList();
            Statement stmt=con.createStatement();
            String query = "select * from jobprovider";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                String id=rs.getString(1);
                userIdList.add(id);
            }
            return userIdList;
        }
        catch(Exception e){
            System.out.println("Error loading jpId");
            return null;
        }
    }
    
    public ArrayList<String> loadUsername(){
        try{
            ArrayList<String> accountIdList = new ArrayList();
            Statement stmt=con.createStatement();
            String query = "select * from user;";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                String un=rs.getString(1);
                accountIdList.add(un);
            }
            return accountIdList;
        }
        catch(Exception e){
            System.out.println("Error loading un");
            return null;
        }
    }
    
    public ArrayList<String> loadPassword(){
        try{
            ArrayList<String> accountIdList = new ArrayList();
            Statement stmt=con.createStatement();
            String query = "select * from user;";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                String pass=rs.getString(2);
                accountIdList.add(pass);
            }
            return accountIdList;
        }
        catch(Exception e){
            System.out.println("Error loading pass");
            return null;
        }
    }
    
    public void saveUser(User u){
        try{
            if(u instanceof JobSeeker){
                String query="insert into user values('"+u.getUsername()+"','"+u.getPassword()+"','"+((JobSeeker) u).getJsId()+"');";
                Statement s = con.createStatement();
                s.execute(query);
            }else{
                String query="insert into user values('"+u.getUsername()+"','"+u.getPassword()+"','"+((JobProvider) u).getJpId()+"');";
                Statement s = con.createStatement();
                s.execute(query);
            }
        }catch(SQLException ex){
            System.out.println("Saving user error");
        }
        System.out.println("Saving user succeed");
        
        try{
            if(u instanceof JobSeeker){
                String query ="insert into jobseeker values('"+((JobSeeker) u).getJsId()+"','"+((JobSeeker) u).getName()+"','"+((JobSeeker) u).getEmail()+"','"+((JobSeeker) u).getContactNum()+"','"+((JobSeeker) u).getAge()+"','"+((JobSeeker) u).getGender()+"','"+((JobSeeker) u).getExperience()+"');";
                Statement s = con.createStatement();
                s.execute(query);
            }else{
                String query ="insert into jobprovider values('"+((JobProvider) u).getJpId()+"','"+((JobProvider) u).getCompanyName()+"','"+((JobProvider) u).getCompanySize()+"','"+((JobProvider) u).getSocialmedia()+"','"+((JobProvider) u).getLinkdn()+"','"+((JobProvider) u).getCompanydesc()+"');";
                Statement s = con.createStatement();
                s.execute(query);
            }
        }catch(SQLException ex){
            System.out.println("Saving user_2 error");
        }
        System.out.println("Saving user_2 succeed");
    }
    
    public User loadSpecificUser(String un){
        User user;
        String pass;
        String roleId;
        try{
            Statement stmt=con.createStatement();
            String query = "select * from user WHERE username='"+un+"';";
            ResultSet rs=stmt.executeQuery(query);
            rs.next();
            pass=rs.getString(2);
            roleId =rs.getString(3);
        }
        catch(Exception e){
            System.out.println("Error loading loadRole");
            return null;
        }
        if(roleId.charAt(1)=='s'){
            user=loadJsUser(un,pass,roleId);
            return user;
        }else{
            user=loadJpUser(un,pass,roleId);
            return user;
        }
    }
    
    public JobSeeker loadJsUser(String un,String pass,String jsId){
        try{
            JobSeeker jobSeeker ;
            Statement stmt=con.createStatement();
            String query = "select * from jobseeker WHERE jsid='"+jsId+"';";
            ResultSet rs=stmt.executeQuery(query);
            rs.next();
            String name=rs.getString(2);
            String email=rs.getString(3);
            String contactnum=rs.getString(4);
            String age=rs.getString(5);
            String gender=rs.getString(6);
            String experience=rs.getString(7);
            jobSeeker = new JobSeeker(un,pass,jsId,name,email,contactnum,age,gender,experience);
            
            return jobSeeker;
        }catch(Exception e){
            System.out.println("Error loading loadRole");
            return null;
        }
    }
    
    public JobProvider loadJpUser(String un,String pass,String jpId){
        try{
            JobProvider jobProvider ;
            Statement stmt=con.createStatement();
            String query = "select * from jobprovider WHERE jpid='"+jpId+"';";
            ResultSet rs=stmt.executeQuery(query);
            rs.next();
            String companyName=rs.getString(2);
            String companySize=rs.getString(3);
            String socialmedia=rs.getString(4);
            String linkdn=rs.getString(5);
            String companydesc=rs.getString(6);
            jobProvider= new JobProvider(un,pass,jpId,companyName,companySize,socialmedia,linkdn,companydesc);
            return jobProvider;
        }catch(Exception e){
            System.out.println("Error loading loadRole");
            return null;
        }
    }
    
    public void SaveJSProfile(String jsid, String fullname, String email, String contactnum, String age, String gender, String experience){
        try{
            String query = "UPDATE `jobseeker` SET `fullname`='"+fullname+"',`email`='"+email+"',`contactnum`='"+contactnum+"',`age`='"+age+"',`gender`='"+gender+"',`experience`='"+experience+"' WHERE jsid='"+jsid+"'" ;
            Statement s = con.createStatement();
            s.execute(query);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void SaveJPProfile(String jpid, String companyname, String companysize, String socialmedia, String linkedn, String companydesc){
        try{
            String query = "UPDATE `jobprovider` SET `companyname`='"+companyname+"',`companysize`='"+companysize+"',`socialmedia`='"+socialmedia+"',`linkedn`='"+linkedn+"',`companydescription`='"+companydesc+"' WHERE jpid='"+jpid+"'" ;
            Statement s = con.createStatement();
            s.execute(query);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void saveVacancy(String vid, String jpid, String title, String salary, String type, String desc, String status){
        try{
            String query="insert into vacancy values('"+vid+"','"+jpid+"','"+title+"','"+salary+"','"+type+"','"+desc+"','"+status+"');";
            Statement s = con.createStatement();
            s.execute(query);
        }catch(Exception e){
            e.printStackTrace();
            
        }
    }
    
    public ArrayList<String> loadVacancyId(){
        try{
            ArrayList<String> userIdList = new ArrayList();
            Statement stmt=con.createStatement();
            String query = "select * from vacancy";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                String id=rs.getString(1);
                userIdList.add(id);
            }
            return userIdList;
        }
        catch(Exception e){
            System.out.println("Error loading jsId");
            return null;
        }
    }
    
    public ArrayList<Vacancy> loadVacancyFromSpecificUser1(String jpid){
        ArrayList<Vacancy> vaclist = new ArrayList();
        try{
            Statement stmt=con.createStatement();
            String query = "select * from vacancy WHERE jpid='"+jpid+"' and vacancystatus='posted';";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                Vacancy vacancy = new Vacancy(rs.getString(1), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
                vaclist.add(vacancy);
            }
            return vaclist;
        }
        catch(Exception e){
            System.out.println("Error loading Vacancy");
            return vaclist;
        }
        
    }
    
    public ArrayList<Vacancy> loadVacancyFromSpecificUser2(String jpid){
        ArrayList<Vacancy> vaclist = new ArrayList();
        try{
            Statement stmt=con.createStatement();
            String query = "select * from vacancy WHERE jpid='"+jpid+"';";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                Vacancy vacancy = new Vacancy(rs.getString(1), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
                vaclist.add(vacancy);
            }
            return vaclist;
        }
        catch(Exception e){
            System.out.println("Error loading Vacancy");
            return vaclist;
        }
        
    }
    
    public ArrayList<Message> loadMessageFromSpecificUser(String roleid){
        ArrayList<Message> vaclist = new ArrayList();
         try{
            Statement stmt=con.createStatement();
            String query = "select * from message WHERE roleid='"+roleid+"';";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                Message vacancy = new Message(rs.getString(1),rs.getString(3),rs.getString(4));
                vaclist.add(vacancy);
            }
            return vaclist;
        }
        catch(Exception e){
            System.out.println("Error loading Vacancy");
            return vaclist;
        }
        
    }
    
    public void saveMessage(String mid, String roleid, String messagepreview, String messagedetails){
        try{
            String query="insert into message values('"+mid+"','"+roleid+"','"+messagepreview+"','"+messagedetails+"');";
            Statement s = con.createStatement();
            s.execute(query);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public ArrayList<String> loadMessageId(){
        try{
            ArrayList<String> userIdList = new ArrayList();
            Statement stmt=con.createStatement();
            String query = "select * from message";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                String id=rs.getString(1);
                userIdList.add(id);
            }
            return userIdList;
        }
        catch(Exception e){
            System.out.println("Error loading jsId");
            return null;
        }
    }
    
    public void deleteMessage(String data){
        try{
            String query="DELETE FROM `message` WHERE mid='"+data+"'";
            Statement s = con.createStatement();
            s.execute(query);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public ArrayList<Vacancy> loadAllVacancy(){
        ArrayList<Vacancy> vaclist = new ArrayList();
        try{
            Statement stmt=con.createStatement();
            String query = "select * from vacancy where vacancystatus='posted';";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                Vacancy vacancy = new Vacancy(rs.getString(1), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
                vaclist.add(vacancy);
            }
            return vaclist;
        }
        catch(Exception e){
            System.out.println("Error loading Vacancy");
            return vaclist;
        }
    }
    
    public ArrayList<JobSeeker> loadApplicant1(String vid){
        ArrayList<String> jsid = new ArrayList();
        try {
            Statement stmt=con.createStatement();
            String query = "select * from applicant where vid='"+vid+"';";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                String temp = rs.getString(3);
                jsid.add(temp);
            }
            try {
                ArrayList<JobSeeker> jslist = new ArrayList();
                for (int i = 0; i < jsid.size(); i++) {
                    Statement stm=con.createStatement();
                    String quer = "select * from jobseeker where jsid='"+jsid.get(i)+"';";
                    ResultSet r=stm.executeQuery(quer);    
                    r.next();
                    JobSeeker temp = new JobSeeker("", "", jsid.get(i), r.getString(2), r.getString(3),r.getString(4),r.getString(5),r.getString(6),r.getString(7));
                    jslist.add(temp);
                    
                }
                return jslist;
                
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            return null ;
        }
    }
    
    public JobProvider loadJpUser2(String vid){
        try{
            JobProvider jobProvider ;
            Statement stmt=con.createStatement();
            String query = "select * from vacancy WHERE vid='"+vid+"';";
            ResultSet rs=stmt.executeQuery(query);
            rs.next();
            String jpid=rs.getString(2);
            
            try{
                stmt=con.createStatement();
                query =  "select * from jobprovider WHERE jpid='"+jpid+"';";
                rs=stmt.executeQuery(query);
                rs.next();
                
                jobProvider = new JobProvider("", "", jpid, rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
                return jobProvider;
                
            }catch(Exception e){
                e.printStackTrace();
                return null;
            }
            
            
        }catch(Exception e){
            System.out.println("Error loading loadRole");
            return null;
        }
    }
    
    public Vacancy loadVacancy(String vid){
        Vacancy vacancy ;
        try {
            Statement stmt=con.createStatement();
            String query = "select * from vacancy where vid='"+vid+"';";
            ResultSet rs=stmt.executeQuery(query);
            rs.next();
            vacancy = new Vacancy(vid, rs.getString(3), rs.getString(4),rs.getString(5), rs.getString(6),rs.getString(7));
            return vacancy;
            
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void saveApplicant(String aid,String vid, String jsid){
        try{
            String query="insert into applicant values('"+aid+"','"+vid+"','"+jsid+"','0');";
            Statement s = con.createStatement();
            s.execute(query);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public ArrayList<String> loadApplicantId(){
        try{
            ArrayList<String> userIdList = new ArrayList();
            Statement stmt=con.createStatement();
            String query = "select * from applicant";
            ResultSet rs=stmt.executeQuery(query);
            while (rs.next()){
                String id=rs.getString(1);
                userIdList.add(id);
            }
            return userIdList;
        }
        catch(Exception e){
            System.out.println("Error loading AId");
            return null;
        }
    }
    
    public boolean checkApply(String vid, String jsid){
        try {
            Statement stmt=con.createStatement();
            String query= "select * from applicant where vid='"+vid+"' and jsid='"+jsid+"';";
            ResultSet rs=stmt.executeQuery(query);
            
            
            if(rs.next()){
                return false;
            }else{
                return true;
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public String loadMessageSented(String vid, String jsid){
        try {
            Statement stmt=con.createStatement();
            String query= "select * from applicant where vid='"+vid+"' and jsid='"+jsid+"';";
            ResultSet rs=stmt.executeQuery(query);
            
            rs.next();
            return rs.getString(4);
            
            
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
    
    public void saveMessageSented(String vid, String jsid, String data){
        try {
            Statement stmt=con.createStatement();
            String temp = String.valueOf(Integer.parseInt(data)+1);
            String query= "UPDATE `applicant` SET `messagesent`='"+temp+"' where vid='"+vid+"' and jsid='"+jsid+"';";
            stmt.execute(query);
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

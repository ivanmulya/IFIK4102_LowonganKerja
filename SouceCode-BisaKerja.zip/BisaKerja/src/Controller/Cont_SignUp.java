/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.JobSeeker;
import Model.Model;
import View.GUI_SignIn;
import View.GUI_SignUp;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Mulyadi
 */
public class Cont_SignUp implements ActionListener{
    GUI_SignUp gui_signup;
    Model model;

    public Cont_SignUp(Model model) {
        gui_signup = new GUI_SignUp();
        gui_signup.setVisible(true);
        gui_signup.addActionListener(this);
        this.model=model;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source=e.getSource();
        if(source.equals(gui_signup.getBTN_BackSU())){
            Cont_SignIn cont_SignIn = new Cont_SignIn(model);
            gui_signup.dispose();
        }
        if(source.equals(gui_signup.getBTN_SignupSU())){
            String un = gui_signup.getTF_UsernameSU();
            String pass = gui_signup.getTF_PasswordSU();
            String roleId = model.setRoleId(gui_signup.getCB_RoleSU_Index());
            
            if(un.equals("")||pass.equals("")){
                gui_signup.showErrorDialog("field must be filled with character(s)");
            }else if(roleId.equals("")){
                gui_signup.showErrorDialog("role is not selected yet");
            }else if(pass.length()<=5){
                gui_signup.showErrorDialog("password must be more or less than 6 character(s)");
            }else if(!model.checkUsername(un)){
                gui_signup.showErrorDialog("username is already registered");
            }
            else{
                model.registerUser(un, pass, roleId);
                model.loadUser(un);
                gui_signup.showPlainDialog("Sign Up Succes");
                if(model.getUser() instanceof JobSeeker){
                    Cont_JobSeeker cont_JobSeeker = new Cont_JobSeeker(model);
                }else{
                    Cont_JobProvider jobProviderCont = new Cont_JobProvider(model);
                }
                
                gui_signup.dispose();
            }
        }

    }
    
    
}

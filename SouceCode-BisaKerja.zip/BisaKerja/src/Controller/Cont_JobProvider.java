/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.JobProvider;
import Model.Model;
import View.GUI_JobProvider;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author Mulyadi
 */
public class Cont_JobProvider extends MouseAdapter implements ActionListener{
    GUI_JobProvider gui_jobprovider;
    Model model;

    public Cont_JobProvider(Model model) {
        gui_jobprovider = new GUI_JobProvider();
        gui_jobprovider.setVisible(true);
        gui_jobprovider.addActionListener(this);
        gui_jobprovider.addMouseListener(this); 
        this.model = model;
        
        
        if( ((JobProvider) model.getUser()).getCompanyName().equals("") || 
                ((JobProvider) model.getUser()).getCompanySize().equals("") || 
                ((JobProvider) model.getUser()).getSocialmedia().equals("") || 
                ((JobProvider) model.getUser()).getLinkdn().equals("") ||
                ((JobProvider) model.getUser()).getCompanydesc().equals("") ){
            gui_jobprovider.setSpecificPanelOnly();
            gui_jobprovider.showSuccesDialog("Fill all your profile before continue.");
        }
        gui_jobprovider.setProfile(
                ((JobProvider) model.getUser()).getCompanyName(),
                ((JobProvider) model.getUser()).getCompanySize(), 
                ((JobProvider) model.getUser()).getSocialmedia(), 
                ((JobProvider) model.getUser()).getLinkdn(),
                ((JobProvider) model.getUser()).getCompanydesc());
        
        model.loadMessageList(((JobProvider) model.getUser()).getJpId());
        model.loadVacancyList1(((JobProvider) model.getUser()).getJpId());
        gui_jobprovider.setLST_MessageJP(model.getMessagelist1());
        gui_jobprovider.setLST_PostedvacancylistJP(model.getVacancylist());
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source=e.getSource();
        
        if(source.equals(gui_jobprovider.getBTN_RefreshJP())){                                                                           //BUTTON REFRESH
            model.loadUser(model.getUser().getUsername());
            gui_jobprovider.setProfile(
                ((JobProvider) model.getUser()).getCompanyName(),
                ((JobProvider) model.getUser()).getCompanySize(), 
                ((JobProvider) model.getUser()).getSocialmedia(), 
                ((JobProvider) model.getUser()).getLinkdn(),
                 ((JobProvider) model.getUser()).getCompanydesc());
            gui_jobprovider.resetViewRequestPage();
            
            String[] temp = new String[0];
            gui_jobprovider.setTA_MessagedetailsJP("");
            gui_jobprovider.setLST_ApplicantlistJP(temp);
            
            model.loadMessageList(((JobProvider) model.getUser()).getJpId());
            model.loadVacancyList1(((JobProvider) model.getUser()).getJpId());
            gui_jobprovider.setLST_MessageJP(model.getMessagelist1());
            gui_jobprovider.setLST_PostedvacancylistJP(model.getVacancylist());
        }
        
        
        
        
        if(source.equals(gui_jobprovider.getBTN_LogoutJP())){                                                               //BUTTON LOGOUT
            gui_jobprovider.dispose();
            Cont_SignIn cont_SignIn = new Cont_SignIn(model);    
        }
        
        
        
        
        if(source.equals(gui_jobprovider.getBTN_UpdateJP())){                                                                           //BUTTON UPDATE PROFILE
            String jpid=((JobProvider) model.getUser()).getJpId();
            String companyname=gui_jobprovider.getTF_CompanynameJP();
            String companysize=gui_jobprovider.getCB_CompanysizeJP();
            String socialmedia=gui_jobprovider.getTF_SocialmediaJP();
            String linkdn=gui_jobprovider.getTF_LinkednJP();
            String companydesc=gui_jobprovider.getTA_CompanyDescriptionJP();
            
            
            
            if( jpid.equals("") || companyname.equals("")|| companysize.equals("") || socialmedia.equals("") ||
                    linkdn.equals("")||companydesc.equals("")){
                gui_jobprovider.showSuccesDialog("Fill all your profile before continue.");
                
                
            }else{
                model.updateProfileJPProfile(jpid, companyname, companysize, socialmedia, linkdn, companydesc);
                gui_jobprovider.setOpenAllPanel();
                gui_jobprovider.showSuccesDialog("Update Profile Succes, you may access all tabs");
            }
            gui_jobprovider.setProfile(companyname, companysize,socialmedia, linkdn, companydesc);
            
        }
        
        
        
        
        
        if(source.equals(gui_jobprovider.getBTN_RequestJP())){                                                                                 //BUTTON REQUEST
            String vid= model.generateVid();
            String jpid= ((JobProvider) model.getUser()).getJpId();
            String title=gui_jobprovider.getTF_JobtitleJP();
            String salary = gui_jobprovider.getTF_Salary1JP()+ " " +gui_jobprovider.getTF_Salary2JP();
            String type = gui_jobprovider.getCB_JobtypeJP();
            String desc=gui_jobprovider.getTA_JobdescriptionJP();
            String status = "requested";
            
            if(gui_jobprovider.getTF_JobtitleJP().equals("") || 
                    gui_jobprovider.getTF_Salary1JP().equals("Rp.") || 
                    gui_jobprovider.getTF_Salary2JP().equals("Per-") ||
                    gui_jobprovider.getCB_JobtypeJP_Index()==0 ||
                    gui_jobprovider.getTA_JobdescriptionJP().equals("")){
                gui_jobprovider.showSuccesDialog("Fill all form before continue.");
            }else{
                gui_jobprovider.showSuccesDialog("Job Requested to Admin, please wait for approvement");
                model.registerVacancy(vid, jpid, title, salary, type, desc, status);
                gui_jobprovider.resetViewRequestPage();
                String mid=model.generateMid();
                String preview = "Message from system.";
                String details = "Your vacancy has been requested. Please wait until our admin accepted "
                        + "your request.\n\nRequested Vacancy Details\n Job Title\t\t :  "
                        + title+"\n salary\t\t :  "+salary+"\n job type\t\t :  "+type+"\n job description\t\t :\n"
                        + desc;
                model.registerMessage(mid, jpid, preview, details); 
                model.loadMessageList(((JobProvider) model.getUser()).getJpId());
                model.loadVacancyList1(((JobProvider) model.getUser()).getJpId());
                gui_jobprovider.setLST_MessageJP(model.getMessagelist1());
                gui_jobprovider.setLST_PostedvacancylistJP(model.getVacancylist());
            }
            
        }
        
        
        if(source.equals(gui_jobprovider.getBTN_DeleteJP())){                                                                       //BUTTON DELETE
            if(gui_jobprovider.getSelected_MessagelistJS()!=-1){
                int index = gui_jobprovider.getSelected_MessagelistJS();
                String data=model.getMessagelist3()[index];
                model.deleteMessage(data);
                model.loadMessageList(((JobProvider) model.getUser()).getJpId());
                model.loadVacancyList1(((JobProvider) model.getUser()).getJpId());
                gui_jobprovider.showSuccesDialog("Delete Succes");
                gui_jobprovider.setLST_MessageJP(model.getMessagelist1());
                gui_jobprovider.setLST_PostedvacancylistJP(model.getVacancylist());
                gui_jobprovider.setTA_MessagedetailsJP("");
                
            }else{
                gui_jobprovider.showSuccesDialog("Select the message first.");
                
            }
        }
        
        if(source.equals(gui_jobprovider.getBTN_ViewJP())){                                                                             //BUTTON VIEW
            if(gui_jobprovider.getSelected_ApplicantlistJS()!=-1){
                int index = gui_jobprovider.getSelected_ApplicantlistJS();
                model.setSpecificApplicant(index);
                
                int index2 = gui_jobprovider.getSelected__PostedvacancylistJS();
                model.setSpecificVacancy(index2);
                gui_jobprovider.setVisible(false);
                Cont_JobProviderContinue cont_JobProviderContinue = new Cont_JobProviderContinue(model,gui_jobprovider);
            }
            else{
                gui_jobprovider.showSuccesDialog("Select the Applicant List first");
            }
        }
        
        
    }
    public void mousePressed(MouseEvent e){
        Object source = e.getSource();
        if(source.equals(gui_jobprovider.getLST_MessageJP())){
            if(gui_jobprovider.getLST_MessageJP().getModel().getSize()!=0){
                int index= gui_jobprovider.getSelected_MessagelistJS();
                gui_jobprovider.setTA_MessagedetailsJP(model.getMessagelist2()[index]);
            }
        }
        
        
        if(source.equals(gui_jobprovider.getLST_PostedvacancylistJP())){
            if(gui_jobprovider.getLST_PostedvacancylistJP().getModel().getSize()!=0){
                int index = gui_jobprovider.getSelected__PostedvacancylistJS();
                gui_jobprovider.setLST_ApplicantlistJP(model.getApplicantList(index));
            }
            
        }
    }
     
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.JobSeeker;
import Model.Model;
import View.GUI_JobSeeker;
import View.GUI_SignIn;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Mulyadi
 */
public class Cont_SignIn implements ActionListener {
    GUI_SignIn gui_signin;
    Model model;

    public Cont_SignIn(Model model) {
        gui_signin = new GUI_SignIn();
        gui_signin.addActionListener(this);
        gui_signin.setVisible(true);
        this.model=model;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source=e.getSource();
        if(source.equals(gui_signin.getBTN_SignupSI())){                                                    //BUTTON SIGNUP
            Cont_SignUp cont_SignUp = new Cont_SignUp(model);
            gui_signin.dispose();
        }
        if(source.equals(gui_signin.getBTN_SigninSI())){                                                //BUTTON SIGNIN
            String un = gui_signin.getTF_UsernameSI();
            String pass = gui_signin.getTF_PasswordSI();
            String roleId;
            
            if(un.equals("") || pass.equals("")){
                gui_signin.showErrorDialog("field must be filled with character(s)");
            }else if(model.checkUsername(un)==true ||  model.checkPassword(pass)==true){
                gui_signin.showErrorDialog("username or password is wrong");
            }else{
                model.loadUser(un);
                
                if(model.getUser() instanceof JobSeeker){
                    Cont_JobSeeker cont_JobSeeker = new Cont_JobSeeker(model);
                }else{
                    Cont_JobProvider jobProviderCont = new Cont_JobProvider(model);
                }
                
                gui_signin.dispose();
                
            }
        }
        
        if(source.equals(gui_signin.getBTN_ExitSI())){                                                          //BUTTON EXIT
            gui_signin.dispose();
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.JobSeeker;
import Model.Model;
import View.GUI_JobSeeker;
import View.GUI_JobSeekerContinue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Mulyadi
 */
public class Cont_JobSeekerContinue implements ActionListener{
    GUI_JobSeekerContinue gui_jobSeekerC;
    Model model;
    GUI_JobSeeker gui_js;

    public Cont_JobSeekerContinue(Model model, GUI_JobSeeker gui_js) {
        gui_jobSeekerC = new GUI_JobSeekerContinue();
        gui_jobSeekerC.setVisible(true);
        gui_jobSeekerC.addActionListener(this);
        this.model = model;
        this.gui_js = gui_js;
        
        
        String data ;
        data = "Job Details\n"
                +" Company\t\t :  "+model.getSpecificJobProvider().getCompanyName()+"\n"
                +" Company Social Media\t :  "+model.getSpecificJobProvider().getSocialmedia()+"\n"
                +" Job\t\t :  "+model.getSpecificVacancy().getVacancyTitle()+"\n"                
                +" Salary\t\t :  "+model.getSpecificVacancy().getSalary()+"\n"
                +" Job Type\t\t :  "+model.getSpecificVacancy().getVacancyType()+"\n"
                +" Job Description\t :  \n"+model.getSpecificVacancy().getVacancyDesc();
        gui_jobSeekerC.setTA_VacancydetailsJS(data);
        
    }
    
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        if(source.equals(gui_jobSeekerC.getBTN_BackJS())){
            gui_jobSeekerC.dispose();
            gui_js.setVisible(true);
            
            String[] temp = new String[0];
            gui_js.setLST_MessageJS(temp);
            gui_js.setTA_MessagedetailsJS("");
            
            model.loadMessageList(((JobSeeker) model.getUser()).getJsId());
            gui_js.setLST_MessageJS(model.getMessagelist1());
        }
        
        
        if(source.equals(gui_jobSeekerC.getBTN_ApplyJS())){
            String aid = model.generateAid();
            String vid = model.getSpecificVacancy().getVacancyId();
            String jsid= ((JobSeeker) model.getUser()).getJsId();
            
            if(model.checkApplyApplicant(vid, jsid)){
                model.registerApplicant(aid, vid, jsid);
                gui_jobSeekerC.showSuccesDialog("Apply Sent to Job Provide, please wait for further message from the Job Provider.");
                
                String mid=model.generateMid();
                String preview = "Message from system.";
                String details = "Your apply has been sent. please wait for further message from the Job Provider.\n\n"
                        +"Apply Details\n"
                        +" Company\t\t :  "+model.getSpecificJobProvider().getCompanyName()+"\n"
                        +" Company Social Media\t :  "+model.getSpecificJobProvider().getSocialmedia()+"\n"
                        +" Job\t\t :  "+model.getSpecificVacancy().getVacancyTitle()+"\n"                        
                        +" Salary\t\t :  "+model.getSpecificVacancy().getSalary()+"\n"
                        +" Job Type\t\t :  "+model.getSpecificVacancy().getVacancyType()+"\n"
                        +" Job Description\t :  \n"+model.getSpecificVacancy().getVacancyDesc()+"\n\n"
                        +" Applied by\t\t :  "+((JobSeeker)model.getUser()).getName();
                model.registerMessage(mid, jsid, preview, details); 
                
                
            }else{
                gui_jobSeekerC.showSuccesDialog("You Already apply this Vacancy, please wait for further message from the Job Provider.");
                
            }
            
                        
        }
    }
    
}

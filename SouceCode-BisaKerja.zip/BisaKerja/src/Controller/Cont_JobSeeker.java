/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.JobSeeker;
import Model.Model;
import View.GUI_JobSeeker;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author Mulyadi
 */
public class Cont_JobSeeker extends MouseAdapter implements ActionListener{
    GUI_JobSeeker gui_jobseeker ;
    Model model;
    

    public Cont_JobSeeker(Model model) {
        gui_jobseeker = new GUI_JobSeeker();
        gui_jobseeker.setVisible(true);
        gui_jobseeker.addActionListener(this);
        gui_jobseeker.addMouseListener(this);
        this.model = model;
        
        
        
        
        if( ((JobSeeker) model.getUser()).getName().equals("") || 
                ((JobSeeker) model.getUser()).getEmail().equals("") || 
                ((JobSeeker) model.getUser()).getContactNum().equals("") ||
                ((JobSeeker) model.getUser()).getAge().equals("") || 
                ((JobSeeker) model.getUser()).getGender().equals("") ||
                ((JobSeeker) model.getUser()).getExperience().equals("")){
            gui_jobseeker.setSpecificPanelOnly();
            gui_jobseeker.showSuccesDialog("Fill all your profile before continue.");
        }
        gui_jobseeker.setProfile(
                    ((JobSeeker) model.getUser()).getName(), 
                    ((JobSeeker) model.getUser()).getEmail(),
                    ((JobSeeker) model.getUser()).getContactNum(), 
                    ((JobSeeker) model.getUser()).getAge(), 
                    ((JobSeeker) model.getUser()).getGender(), 
                    ((JobSeeker) model.getUser()).getExperience());
        
        model.loadVacancyList2();
        model.loadMessageList(((JobSeeker) model.getUser()).getJsId());
        gui_jobseeker.setLST_MessageJS(model.getMessagelist1());
        gui_jobseeker.setLST_VacancylistJS(model.getVacancylist());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source=e.getSource();
        if(source.equals(gui_jobseeker.getBTN_RefreshJS())){                                            //button refresh
            model.loadUser(model.getUser().getUsername());
            gui_jobseeker.setProfile(
                    ((JobSeeker) model.getUser()).getName(), 
                    ((JobSeeker) model.getUser()).getEmail(),
                    ((JobSeeker) model.getUser()).getContactNum(), 
                    ((JobSeeker) model.getUser()).getAge(), 
                    ((JobSeeker) model.getUser()).getGender(), 
                    ((JobSeeker) model.getUser()).getExperience());
            
            String[] temp = new String[0];
            gui_jobseeker.setLST_MessageJS(temp);
            gui_jobseeker.setTA_MessagedetailsJS("");
            
            model.loadMessageList(((JobSeeker) model.getUser()).getJsId());
            gui_jobseeker.setLST_MessageJS(model.getMessagelist1());
            model.loadVacancyList2();
            gui_jobseeker.setLST_VacancylistJS(model.getVacancylist());
        }
        
        
        
        
        
        
        
        
        if(source.equals(gui_jobseeker.getBTN_LogoutJS())){                                             //button logout
            gui_jobseeker.dispose();
            Cont_SignIn cont_SignIn = new Cont_SignIn(model);    
        }
        
        
        
        
        
        
        
        if(source.equals(gui_jobseeker.getBTN_UpdateJS())){                                                                 //buton update profile
            String jsid=((JobSeeker)model.getUser()).getJsId();
            String fullname=gui_jobseeker.getTF_FullnameJS();
            String email=gui_jobseeker.getTF_EmailJS();
            String contactnum=gui_jobseeker.getTF_ContactnumJS();
            String age = gui_jobseeker.getTF_AgeJS();
            String gender = gui_jobseeker.getBG_GenderJS();
            String experience = gui_jobseeker.getBG_ExperienceJS();
            
            
            
            if( fullname.equals("") || email.equals("") || contactnum.equals("") || age.equals("") || 
                    gender.equals("") || experience.equals("")){
                gui_jobseeker.showSuccesDialog("Fill all your profile before continue.");
                
            }else{
                model.updateProfileJSProfile(jsid,fullname, email, contactnum, age, gender, experience); //include save to database
                gui_jobseeker.setOpenAllPanel();
                gui_jobseeker.showSuccesDialog("Update Profile Succes, you may access all tabs");
            }
            gui_jobseeker.setProfile(fullname, email, contactnum, age, gender, experience);
        }
        
        
        
        
        if(source.equals(gui_jobseeker.getBTN_DeleteJS())){                                                                             //button delete
            if(gui_jobseeker.getSelected_MessagelistJS()!=-1){
                int index = gui_jobseeker.getSelected_MessagelistJS();
                String data=model.getMessagelist3()[index];
                model.deleteMessage(data);
                model.loadMessageList(((JobSeeker) model.getUser()).getJsId());
                gui_jobseeker.showSuccesDialog("Delete Succes");
                gui_jobseeker.setLST_MessageJS(model.getMessagelist1());
                gui_jobseeker.setTA_MessagedetailsJS("");
                model.loadVacancyList2();
                gui_jobseeker.setLST_VacancylistJS(model.getVacancylist());
                
            }else{
                gui_jobseeker.showSuccesDialog("Select the message first.");
                
            }
        }
        
        if(source.equals(gui_jobseeker.getBTN_ViewJS())){                                                                                   //button view
            if(gui_jobseeker.getSelected_VacancylistJS()!=-1){
                int index = gui_jobseeker.getSelected_VacancylistJS();
                model.setSpecificJobProvider(index);
                model.setSpecificVacancy(index);
                gui_jobseeker.setVisible(false);
                Cont_JobSeekerContinue cont_JobSeekerContinue = new Cont_JobSeekerContinue(model, gui_jobseeker);

//                String[] temp = new String[0];
//                gui_jobseeker.setLST_MessageJS(temp);
//                gui_jobseeker.setTA_MessagedetailsJS("");
//                
//                model.loadMessageList(((JobSeeker) model.getUser()).getJsId());
//                gui_jobseeker.setLST_MessageJS(model.getMessagelist1());
//                
            }
            else{
                gui_jobseeker.showSuccesDialog("Select the vacancy first");
            }
            
        }
        
        
    }
    
     public void mousePressed(MouseEvent e){
        Object source = e.getSource();
        if(source.equals(gui_jobseeker.getLST_MessageJS())){
            if(gui_jobseeker.getLST_MessageJS().getModel().getSize()!=0){
                int index= gui_jobseeker.getSelected_MessagelistJS();
                gui_jobseeker.setTA_MessagedetailsJS(model.getMessagelist2()[index]);
            }
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.JobProvider;
import Model.JobSeeker;
import Model.Model;
import View.GUI_JobProvider;
import View.GUI_JobProviderContinue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Mulyadi
 */
public class Cont_JobProviderContinue implements  ActionListener{
    GUI_JobProviderContinue gui_jobProviderC;
    Model model;
    GUI_JobProvider gui_jp;

    public Cont_JobProviderContinue(Model model, GUI_JobProvider jp) {
        gui_jobProviderC = new GUI_JobProviderContinue();
        gui_jobProviderC.setVisible(true);
        gui_jobProviderC.addActionListener(this);
        this.model=model;
        this.gui_jp=jp;
        
        JobSeeker applicant= model.getSpecificApplicant();
            String exp;
            if(applicant.getExperience().equals("intermediate")){
                exp="Begginer -  have been working with these skills\n\t\t    for 2 to 5 years and can complete most common task";
            }else if (applicant.getExperience().equals("advanced")){
                exp="Advanced - have been working with these skills\n\t\t    for more than 5 years and are an expert in them";
            }else{
                exp="Beginer - have been working with these skills\n\t\t    for less than a year and are still learning";
            }
            String data =
                    "Data Applicant\n"
                    +" Name\t\t :  "+applicant.getName()+"\n"
                    +" Age\t\t :  "+applicant.getAge()+"\n"
                    +" Gender\t\t :  "+applicant.getGender()+"\n"
                    +" Experience\t\t :  "+exp+"\n"
                    +" Email\t\t :  "+applicant.getEmail()+"\n"
                    +" Contact number\t :  "+applicant.getContactNum() ; 
            gui_jobProviderC.setTA_ApplicantdetailsJP(data);
//            model.getSpecificVacancy().getVacancyId(), applicant.getJsId(), model.getMessageSented(model.getSpecificVacancy().getVacancyId(), applicant.getJsId())
            gui_jobProviderC.setLabelspecial("*message sent : "+model.getMessageSented(model.getSpecificVacancy().getVacancyId(), applicant.getJsId()));
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        if(source.equals(gui_jobProviderC.getBTN_SendJP())){
            String details="";
            if(gui_jobProviderC.getTA_FeedbackmessageJP().equals("")){
                gui_jobProviderC.showSuccesDialog("Write the Message First");
            }else{
                
                String mid= model.generateMid();
                String preview = "Response From : "+((JobProvider) model.getUser()).getCompanyName() ;
                String jsid= model.getSpecificApplicant().getJsId();
                details = gui_jobProviderC.getTA_FeedbackmessageJP();
                model.registerMessage(mid, jsid, preview, details);
                
                gui_jobProviderC.showSuccesDialog("Message Sent");
                gui_jobProviderC.setTA_FeedbackmessageJP("");
                model.setMessageSentedPlus1(model.getSpecificVacancy().getVacancyId(), jsid, model.getMessageSented(model.getSpecificVacancy().getVacancyId(), jsid));
                gui_jobProviderC.setLabelspecial("*message sent : "+model.getMessageSented(model.getSpecificVacancy().getVacancyId(), jsid));
            }
        }
        
        if(source.equals(gui_jobProviderC.getBTN_BackJP())){
            gui_jobProviderC.dispose();
            this.gui_jp.setVisible(true);
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database.Database;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Mulyadi
 */
public class Model {
    Database db;
    User user;
    ArrayList<Vacancy> vacancyreqlist = new ArrayList();
    ArrayList<Vacancy> vacancypostlist = new ArrayList();
    ArrayList<User> userlist = new ArrayList();
    JobSeeker specificApplicant;
    JobProvider specificJobProvider;
    Vacancy specificVacancy;

     
    public Model() {
        db = new Database();
        db.connect();
    }

    public ArrayList<Vacancy> getVacancypostlist() {
        return vacancypostlist;
    }

    public ArrayList<User> getUserlist() {
        return userlist;
    }
    
    
    
    public ArrayList<Vacancy> getVacancyreqlist() {
        return vacancyreqlist;
    }
    
    public String generateMid(){
        ArrayList<String> listUser = new ArrayList();
        listUser= db.loadMessageId();
        
        if(listUser.isEmpty()){
            return "mid1";
        }
        else{
            int n = listUser.size();
            int[] arr = new int[n+1];
            for (int i = 0; i < n; i++) {
                arr[i]= Integer.parseInt ( listUser.get(i).replace("mid", ""));
            }
            arr[n]=999999999;
            Arrays.sort(arr);

            
            int a = 1;
            int i = 0;
            while(arr[i]==a && a<=n){
                if(a==arr[i]){
                    a += 1;
                    i += 1;
                }
            }
            return "mid"+String.valueOf(a); 
        }
    }
    
    public void registerMessage(String mid, String roleid, String messagepreview, String messagedetails){
        db.saveMessage(mid, roleid, messagepreview, messagedetails);
    }
    
    
    public boolean checkAdminAccount(String un, String pass){
        return db.checkAdminAccount(un,pass);
    }
    
    public void setSpecificJobProvider(String jpid) {
        specificJobProvider=db.loadSpecificJobProvider(jpid);
    }
    
    public String[] getAllVacancyRequested(){
        vacancyreqlist= db.loadRequestedVacancy();
        
        String[] temp= new String[vacancyreqlist.size()];
        for (int i = 0; i < vacancyreqlist.size(); i++) {
            setSpecificJobProvider(vacancyreqlist.get(i).getJpId());
            temp[i]=vacancyreqlist.get(i).getVacancyTitle()+" - "+specificJobProvider.getCompanyName();
        }
        
        return temp;   
    }
    
    public String[] getAllVacancyPosted(){
        vacancypostlist=db.loadPostedVacancy();
        
        String[] temp= new String[vacancypostlist.size()];
        for (int i = 0; i < vacancypostlist.size(); i++) {
            setSpecificJobProvider(vacancypostlist.get(i).getJpId());
            temp[i]=vacancypostlist.get(i).getVacancyTitle()+" - "+specificJobProvider.getCompanyName();
        }
        
        return temp;   
    }
    
    public String[] getAllUser(){
        userlist= db.loadAllUser();
        
        String[] temp= new String[userlist.size()];
        for (int i = 0; i < userlist.size(); i++) {
            if(userlist.get(i) instanceof JobSeeker){
                temp[i]=((JobSeeker) userlist.get(i)).getJsId() +" - "+((JobSeeker) userlist.get(i)).getName();
            }else{
                temp[i]=((JobProvider) userlist.get(i)).getJpId() +" - "+((JobProvider) userlist.get(i)).getCompanyName();
            }
        }
        
        return temp;
    }
    
    
    public String getTA_RequestData1(int index){
        
        Vacancy v=vacancyreqlist.get(index);
        setSpecificJobProvider(v.getJpId());
        return "\t\t\t    Vacancy Details "+"\n"
                +" Vacancy Title\t\t :  "+v.getVacancyTitle()+"\n"
                +" Salary\t\t :  "+v.getSalary()+"\n"
                +" Vacancy Type\t\t :  "+v.getVacancyType()+"\n"
                +" Vacancy Description\t :  "+v.getVacancyDesc()+"\n\n"
                +"\t\t\tJob Provider Details"+"\n"
                +" Company Name\t :  "+specificJobProvider.getCompanyName()+"\n"
                +" Company Size\t\t :  "+specificJobProvider.getCompanySize()+"\n"
                +" Social Media\t\t :  "+specificJobProvider.getSocialmedia()+"\n"
                +" Contact Number\t :  "+specificJobProvider.getLinkdn()+"\n"
                +" Company Description\t :  "+specificJobProvider.getCompanydesc();
    }
    public String getTA_RequestData2(int index){
        
        Vacancy v=vacancypostlist.get(index);
        setSpecificJobProvider(v.getJpId());
        return "\t\t\t    Vacancy Details "+"\n"
                +" Vacancy Title\t\t :  "+v.getVacancyTitle()+"\n"
                +" Salary\t\t :  "+v.getSalary()+"\n"
                +" Vacancy Type\t\t :  "+v.getVacancyType()+"\n"
                +" Vacancy Description\t :  "+v.getVacancyDesc()+"\n\n"
                +"\t\t\tJob Provider Details"+"\n"
                +" Company Name\t :  "+specificJobProvider.getCompanyName()+"\n"
                +" Company Size\t\t :  "+specificJobProvider.getCompanySize()+"\n"
                +" Social Media\t\t :  "+specificJobProvider.getSocialmedia()+"\n"
                +" Contact Number\t :  "+specificJobProvider.getLinkdn()+"\n"
                +" Company Description\t :  "+specificJobProvider.getCompanydesc();
    }
    public String getTA_RequestData3(int index){
        
        User v=userlist.get(index);
        if(v instanceof JobSeeker){
            return "\t\t\t    User Details "+"\n"
                +" Job Seeker Id\t\t :  "+((JobSeeker) v).getJsId()+"\n"
                +" Fullname\t\t :  "+((JobSeeker) v).getName()+"\n"
                +" Email\t\t :  "+((JobSeeker) v).getEmail()+"\n"
                +" Contact number\t :  "+((JobSeeker) v).getContactNum()+"\n"
                +" Age\t\t :  "+((JobSeeker) v).getAge()+"\n"
                +" Gender\t\t :  "+((JobSeeker) v).getGender()+"\n"
                +" Experience\t\t :  "+((JobSeeker) v).getExperience();
        }else if (v instanceof JobProvider){
            return "\t\t\t    User Details "+"\n"
                +" Job Provider Id\t\t :  "+((JobProvider) v).getJpId()+"\n"
                +" Company Name\t :  "+((JobProvider) v).getCompanyName()+"\n"
                +" Company Size\t\t :  "+((JobProvider) v).getCompanySize()+"\n"
                +" Social Media\t\t :  "+((JobProvider) v).getSocialmedia()+"\n"
                +" Contact Number\t :  "+((JobProvider) v).getLinkdn()+"\n"
                +" Company Description\t :  "+((JobProvider) v).getCompanydesc();
        }else{
            return "";
        }
    }
    
    public void changeStatusVacancy(String vid){
        db.setStatusVacancyToPosted(vid);
    }
    
    public void deleteRequestedVacancy(String vid){
        db.deleteVacancy(vid);
    }
    
    public void deleteAvailableVacancy(String vid){
        db.deleteApplicant(vid);
        db.deleteVacancy(vid);
    }
    
    public void deleteUser(String roleid){
        db.deleteUserAll(roleid);
    }
}

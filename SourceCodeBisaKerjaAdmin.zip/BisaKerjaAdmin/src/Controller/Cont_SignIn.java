/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Model;
import View.GUI_SignIn;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Mulyadi
 */
public class Cont_SignIn implements ActionListener {
    Model model;
    GUI_SignIn gui_signin;

    public Cont_SignIn(Model model) {
        this.model = model;
        gui_signin = new GUI_SignIn();
        gui_signin.addActionListener(this);
        gui_signin.setVisible(true);
    }
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        if(source.equals(gui_signin.getBTN_ExitSIADM())){
            gui_signin.dispose();
        }
        
        if(source.equals(gui_signin.getBTN_SigninSIADM())){
            String un=gui_signin.getTF_UsernameSIADM();
            String pass=gui_signin.getTF_PasswordSIADM();
            
            if(un.equals("") || pass.equals("")){
                gui_signin.showErrorDialog("field must be filled with character(s)");
            }else if (!model.checkAdminAccount(un,pass)){
                gui_signin.showErrorDialog("username or password is wrong");
            }else{
                gui_signin.dispose();
                Cont_home cont_home = new Cont_home(model);
            }
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.JobProvider;
import Model.JobSeeker;
import Model.Model;
import Model.Vacancy;
import View.GUI_Home;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author Mulyadi
 */
public class Cont_home extends MouseAdapter implements ActionListener{
    Model model;
    GUI_Home gui_home;

    public Cont_home(Model model) {
        this.model = model;
        gui_home=new  GUI_Home();
        gui_home.setVisible(true);
        gui_home.addActionListener(this);
        gui_home.addMouseListener(this);
        
        gui_home.setLST_UseraccountlistADM(model.getAllUser());
        gui_home.setLST_AvailablevacancylistADM(model.getAllVacancyPosted());
        gui_home.setLST_RequestedvacancylistADM(model.getAllVacancyRequested());
        
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        if(source.equals(gui_home.getBTN_Refresh1ADM())){
            gui_home.setLST_UseraccountlistADM(model.getAllUser());                                                                 //Button refresh
            gui_home.setLST_AvailablevacancylistADM(model.getAllVacancyPosted());
            gui_home.setLST_RequestedvacancylistADM(model.getAllVacancyRequested());
            gui_home.setTA_AvailablevacancydetailsADM("");
            gui_home.setTA_RequestedvacancydetailsADM("");
            gui_home.setTA_UseraccountdetailsADM("");
        }
        
        if(source.equals(gui_home.getBTN_LogoutADM())){                                                                         //button logout
            gui_home.dispose();
            Cont_SignIn cont_SignIn = new Cont_SignIn(model);
        }
        
        if(source.equals(gui_home.getBTN_AcceptADM())){                                                                             //button accpet
            if(gui_home.getSelected_RequestedvacancylistADM()!=-1){
                int index = gui_home.getSelected_RequestedvacancylistADM();
                String vid=model.getVacancyreqlist().get(index).getVacancyId();
                
                Vacancy v=model.getVacancyreqlist().get(index);
                String mid= model.generateMid();
                String roleid=model.getVacancyreqlist().get(index).getJpId();
                String messagepreview="Message from system.";
                String messagedetails = "Your vacancy has been accepted and posted by our admin."+"\n\n"
                        +"Vacancy Details\n"
                        +" Vacancy Title\t\t :  "+v.getVacancyTitle()+"\n"
                        +" Salary\t\t :  "+v.getSalary()+"\n"
                        +" Vacancy Type\t\t :  "+v.getVacancyType()+"\n"
                        +" Vacancy Description\t :  \n"+v.getVacancyDesc();
                model.registerMessage(mid, roleid, messagepreview, messagedetails);
                
                
                
                gui_home.showSuccesDialog("Vacancy "+model.getVacancyreqlist().get(index).getVacancyTitle()+" Accepted");
                model.changeStatusVacancy(vid);
                gui_home.setLST_RequestedvacancylistADM(model.getAllVacancyRequested());
                gui_home.setLST_AvailablevacancylistADM(model.getAllVacancyPosted());
                gui_home.setTA_RequestedvacancydetailsADM("");
                
                
                
                
            }else{
                gui_home.showSuccesDialog("Select the list of requested vacancy first");
            }
        }
        
        if(source.equals(gui_home.getBTN_DeclineADM())){                                                                            //button decline
            if(gui_home.getSelected_RequestedvacancylistADM()!=-1){
                int index = gui_home.getSelected_RequestedvacancylistADM();
                String vid=model.getVacancyreqlist().get(index).getVacancyId();
                
                Vacancy v=model.getVacancyreqlist().get(index);
                String mid= model.generateMid();
                String roleid=model.getVacancyreqlist().get(index).getJpId();
                String messagepreview="Message from system.";
                String messagedetails = "We are sorry... Your vacancy has been decline by our admin. Please try request another vacancy"+"\n\n"
                        +"Vacancy Details\n"
                        +" Vacancy Title\t\t :  "+v.getVacancyTitle()+"\n"
                        +" Salary\t\t :  "+v.getSalary()+"\n"
                        +" Vacancy Type\t\t :  "+v.getVacancyType()+"\n"
                        +" Vacancy Description\t :  \n"+v.getVacancyDesc();
                model.registerMessage(mid, roleid, messagepreview, messagedetails);
                
                
                gui_home.showSuccesDialog("Vacancy "+model.getVacancyreqlist().get(index).getVacancyTitle()+" Declined");
                model.deleteRequestedVacancy(vid);
                gui_home.setLST_RequestedvacancylistADM(model.getAllVacancyRequested());
                gui_home.setTA_RequestedvacancydetailsADM("");
                
                
            }
            else{
                gui_home.showSuccesDialog("Select the list of requested vacancy first");
        }
        
        }
        
        if(source.equals(gui_home.getBTN_Delete1ADM())){                                                                                    //BUtton delete available vacancy
            if(gui_home.getSelected_AvailablevacancylistADM()!=1){
                int index = gui_home.getSelected_AvailablevacancylistADM();
                String vid=model.getVacancypostlist().get(index).getVacancyId();
                
                Vacancy v=model.getVacancypostlist().get(index);
                String mid= model.generateMid();
                String roleid=model.getVacancypostlist().get(index).getJpId();
                String messagepreview="Message from system.";
                String messagedetails = "We are sorry... Your vacancy has been deleted by our admin because our policy."+"\n\n"
                        +"Vacancy Details\n"
                        +" Vacancy Title\t\t :  "+v.getVacancyTitle()+"\n"
                        +" Salary\t\t :  "+v.getSalary()+"\n"
                        +" Vacancy Type\t\t :  "+v.getVacancyType()+"\n"
                        +" Vacancy Description\t :  \n"+v.getVacancyDesc();
                model.registerMessage(mid, roleid, messagepreview, messagedetails);
                
                
                gui_home.showSuccesDialog("Vacancy "+model.getVacancypostlist().get(index).getVacancyTitle()+" Deleted");
                model.deleteAvailableVacancy(vid);
                gui_home.setLST_AvailablevacancylistADM(model.getAllVacancyPosted());
                gui_home.setTA_AvailablevacancydetailsADM("");
            }
            else{
                gui_home.showSuccesDialog("Select the list of available vacancy first");
            }
        }
        
        if(source.equals(gui_home.getBTN_Delete2ADM())){
            if(gui_home.getSelected_UseraccountlistADM()!=-1){
                int index = gui_home.getSelected_UseraccountlistADM();
                String roleid ;
                if(model.getUserlist().get(index) instanceof JobSeeker){
                    roleid=((JobSeeker) model.getUserlist().get(index)).getJsId();
                }else{
                    roleid=((JobProvider) model.getUserlist().get(index)).getJpId();
                }
                
                
                if(model.getUserlist().get(index) instanceof JobSeeker){
                    gui_home.showSuccesDialog("Vacancy "+((JobSeeker) model.getUserlist().get(index)).getJsId()+" Deleted");
                }else{
                    gui_home.showSuccesDialog("Vacancy "+((JobProvider) model.getUserlist().get(index)).getJpId()+" Deleted");
                }
                model.deleteUser(roleid);
                gui_home.setLST_UseraccountlistADM(model.getAllUser());
                gui_home.setTA_UseraccountdetailsADM("");
                
                
                
                
            }
        }
        
    }
    
    public void mousePressed(MouseEvent e){
        Object source = e.getSource();
        
        if(source.equals(gui_home.getLST_RequestedvacancylistADM())){
            if(gui_home.getLST_RequestedvacancylistADM().getModel().getSize()!=0){
                int index= gui_home.getSelected_RequestedvacancylistADM();
                gui_home.setTA_RequestedvacancydetailsADM(model.getTA_RequestData1(index));
            }
        }
        
        if(source.equals(gui_home.getLST_AvailablevacancylistADM())){
            if(gui_home.getLST_AvailablevacancylistADM().getModel().getSize()!=0){
                int index = gui_home.getSelected_AvailablevacancylistADM();
                gui_home.setTA_AvailablevacancydetailsADM(model.getTA_RequestData2(index));
            }
        }
        
        if(source.equals(gui_home.getLST_UseraccountlistADM())){
            if(gui_home.getLST_UseraccountlistADM().getModel().getSize()!=0){
                int index=gui_home.getSelected_UseraccountlistADM();
                gui_home.setTA_UseraccountdetailsADM(model.getTA_RequestData3(index));
                
            }
        }
    }
}
